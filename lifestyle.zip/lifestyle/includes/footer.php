<footer class="text-center py-3 text-white">
  <div class="row no-gutters justify-content-center">
	<p class="col-sm-auto">
	  Copyright &copy; Lifestyle Store.
	</p>
	<p class="col-sm-auto">
	  &nbsp;All Rights Reserved.
	</p>
  </div>
  <p class="mt-2">​Contact Us: <i class="ml-2 fa fa-lg fa-phone fa-inverse"></i> +91 90000 00000</p>
</footer>
